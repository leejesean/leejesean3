import game_framework_maple
import start_state_maple

game_framework_maple.run(start_state_maple)